package com.uptctrabajocampo.ecoclickv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ecoclickv2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ecoclickv2Application.class, args);
	}

}
